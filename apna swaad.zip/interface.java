interface moveable
{
    void move();
    void turnLeft();
    void turnRight();
}

interface airbugs
{
    void openAirbags();
}
interface vehicle extends moveable{
    int wheel = 4;
    void start();
    void start();

    void applyBreak();
}

interface flyer {
    void fly();
}

class Bird implements flyer
{
    public void fly(){
    
    }
}
 class Car implements vehicle {
     public void start(){

     }
 }
      